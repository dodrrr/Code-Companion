# Chain — parche de iconos v1

Preparado a partir de `chain-app-complete(1).zip`, revisión del 6 de septiembre de 2026.

## Qué cambia

Check más ligero; una familia de trazos redondeados para añadir, completar, mínimo, descanso y Freeze. Los marcadores completados del historial muestran un pequeño check además del color. Se aplica en tarjetas, semana/calendario, detalle, Plan y creación de Chain.

Mantiene los significados, colores, tamaños de los controles, animaciones y comportamiento de registro existentes. Usa `react-native-svg`, que ya figura en el package.json del ZIP. No hay dependencias nuevas ni cambios en datos, Gate, suscripciones o reglas de racha. Los defectos funcionales descritos en el informe siguen pendientes.

## Aplicación manual en Replit

1. Guarda un checkpoint o una copia del proyecto actual en Replit.
2. Descomprime este paquete en tu ordenador. Dentro de `reemplazar` están los seis archivos completos.
3. Abre el archivo correspondiente en Replit y sustituye su contenido por el del paquete, respetando la ruta. Empieza por `components/ui/ChainSymbol.tsx`.
4. Repite con los otros cinco archivos de la lista inferior.
5. Recarga la app en Expo Go. Si Replit muestra errores de importación, comprueba que se copiaron los seis archivos y que `ChainSymbol.tsx` está en `components/ui`.

Si la raíz de tu editor ya es `artifacts/chain`, omite ese prefijo al localizar los archivos. Si has modificado alguno desde el ZIP, revisa `chain-icons.patch` y aplica solo sus cambios: sustituir un archivo completo perdería tus cambios posteriores.

Archivos:

- `artifacts/chain/app/(tabs)/plan.tsx`
- `artifacts/chain/app/chain/[id].tsx`
- `artifacts/chain/app/chain/new.tsx`
- `artifacts/chain/components/ChainCard.tsx`
- `artifacts/chain/components/WeekStrip.tsx`
- `artifacts/chain/components/ui/ChainSymbol.tsx`

## Alternativa con patch

Desde la raíz del proyecto que contiene `artifacts/chain`, con `chain-icons.patch` en esa raíz:

```bash
git apply --check chain-icons.patch
git apply chain-icons.patch
```

Ejecuta la segunda línea solo si la primera termina sin errores. No fuerces la aplicación si tu código ya difiere. Para revertir, restaura tu checkpoint o los seis archivos de `originales` si no has hecho más cambios.

## Comprobación en tu proyecto

Desde `artifacts/chain`:

```bash
pnpm run typecheck
pnpm test
```

Después comprueba en Expo Go: una Chain pendiente y una completada; mínimo, descanso y Freeze; los puntos de la semana y el calendario; una tarea completada de Plan; selección de color al crear Chain. Comprueba también texto grande, VoiceOver y Reducir movimiento. El icono es decorativo y conserva la etiqueta accesible del control padre.

## Validación realizada

- Las 75 pruebas existentes del proyecto pasan en la copia con el parche.
- El diff se comprueba contra la copia original antes de entregar; solo cambia seis archivos.
- La lámina de iconos se genera a partir de los mismos paths SVG del componente.
- No se ha ejecutado el proyecto completo en Expo/iPhone. No se ha podido completar el typecheck: el ZIP contiene una parte del monorepo, sin las dependencias instaladas y sin `lib/api-client-react`. Estas comprobaciones siguen pendientes en tu Replit.

El informe incluye cinco reproducciones de fallos de dominio que las pruebas existentes no cubren. Pasar estas 75 pruebas no significa que esos fallos estén corregidos.

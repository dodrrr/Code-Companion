# Chain — revisión del producto y prioridades de mejora

6 de septiembre de 2026 · Código, experiencia de uso y mercado

## La decisión principal

**Cambiaría el check y armonizaría los símbolos de estado. Después corregiría las contradicciones de funcionamiento que hemos encontrado. No ampliaría ahora el catálogo de funciones.** Chain ya tiene bastante profundidad: hábitos diarios y semanales, mínimos, descansos, Freeze, planificación, recordatorios, sesiones de foco y una relación entre tareas y hábitos. Su siguiente salto de calidad depende de que todo eso resulte fiable y fácil de entender.

La investigación identifica cinco problemas reproducibles en las reglas actuales, varios ajustes pequeños de claridad y dos recorridos nativos todavía pendientes: protección de apps y suscripciones. Esto no significa rehacer el producto. Significa terminar bien sus promesas actuales antes de sumar otras.

La dirección que mantendría es esta: **elige algo que quieras sostener, hazle sitio en tu día, protege ese momento y reconoce el progreso real**. El usuario debe entender ese recorrido sin aprender tres sistemas independientes.

## Qué se ha revisado y qué significa la evidencia

La base es el ZIP actual de Chain y la captura aportada, junto con documentación primaria de siete competidores y fuentes oficiales de Apple y Expo. Las referencias de código se expresan desde `artifacts/chain/` y apuntan a las líneas de la copia original; pueden desplazarse al aplicar el parche visual.

Se distinguen tres niveles. **Confirmado** significa que el código o una reproducción de sus funciones demuestra el comportamiento descrito. **Recomendación de diseño** significa que proponemos una forma más clara de presentar ese comportamiento, pendiente de comprobar con usuarios. **Pendiente nativo** significa que no puede acreditarse desde la ejecución JavaScript revisada.

Las 75 pruebas existentes pasan. Además, se reprodujeron cinco casos de dominio o de combinación de los mismos selectores que usa la interfaz. Que la suite pase no significa que cubra esos cinco casos. El ZIP contiene la app dentro de un monorepo incompleto: faltan dependencias instaladas y el paquete local `lib/api-client-react`. No se ha completado una comprobación integral de TypeScript, una compilación iOS ni una prueba física en iPhone. Tampoco se ha validado VoiceOver, StoreKit, Screen Time o las notificaciones reales del dispositivo. El informe conserva esos límites.

## El check: una mejora de familia, no un rediseño global

Tu impresión tiene sentido como decisión estética: el check es una interacción que se repite mucho y merece sentirse cuidado. Lo resolvería manteniendo su significado reconocible, con trazo más equilibrado, extremos redondeados y el mismo criterio óptico para mínimo, descanso y Freeze. **No convertiría el check en un eslabón abstracto:** el eslabón identifica la marca, mientras que el check debe seguir diciendo “completado” de inmediato.

El check actual usa un símbolo de peso semibold en iOS, mientras convive con iconos de contorno de otra familia. El parche usa una cuadrícula SVG de 24 unidades y trazos redondeados, con un pequeño refuerzo en marcadores de 12–14 px. La app ya centraliza símbolos en `components/ui/ChainSymbol.tsx:7–15`. Eso permite mejorar la consistencia sin sustituir todos los iconos de navegación. El parche preparado es visual y afecta a seis archivos: `components/ui/ChainSymbol.tsx`, `components/ChainCard.tsx`, `components/WeekStrip.tsx`, `app/chain/[id].tsx`, `app/(tabs)/plan.tsx` y `app/chain/new.tsx`. Unifica los símbolos de las acciones equivalentes y conserva estados distinguibles.

Ese parche **no corrige todavía** las reglas de mínimo, Freeze o recurrencias descritas más adelante. Esta separación permite comprobar primero el aspecto y aplicar después cambios de funcionamiento con sus propias verificaciones. Las 75 pruebas siguen pasando, pero la geometría del SVG se ha revisado en una lámina técnica; el resultado visual debe comprobarse también en Expo Go en tu iPhone. La suite no acredita tamaño óptico, respuesta táctil ni lectura en pantalla real.

## Qué ofrece ya el mercado

La comparación cubre tres trabajos: sostener hábitos, organizar el día y proteger la atención. No es una clasificación absoluta de las mejores apps ni una estimación del tamaño de mercado.

Los precios siguientes son referencias observadas: App Store estadounidense en USD, salvo Opal y ScreenZen, que se toman de su web. Las compras integradas pueden listar variantes o promociones; no garantizan la misma oferta para cada alta, país o plataforma.

| Producto | Núcleo confirmado | Precio observado | Implicación para Chain |
|---|---|---|---|
| Streaks | Rachas, frecuencias configurables, temporizadores, widgets, Health, Watch e iCloud. | $5.99 inicial. | Registrar hábitos ya tiene una alternativa madura de pago único. [S01] |
| HabitKit | Cuadrículas de progreso, objetivos flexibles, descansos, widgets, edición del historial y exportación. | SKUs $1.99/mes, $11.99/año, $29.99 vitalicio; aparecen otras variantes. | Claridad visual y control del historial pueden aportar valor sin muchas pantallas. [S02, S03] |
| Habitify | Hábitos y recordatorios; Pro amplía descansos, listas, calendarios, salud, Screen Time y automatización. | Plus $29.99/año; Pro $8.99/mes o $49.99/año. Su ayuda indica compromiso de 12 meses para Pro mensual en iOS. | No conviene competir ahora en número de integraciones. [S04, S05] |
| Structured | Plan visual, tareas con duración, bandeja sin fecha, recurrencias y reajuste del día. | $6.99/mes, $29.99/año, $99.99 vitalicio, según ayuda oficial para EE. UU. | Plan debe facilitar actuar y reorganizarse, sin transformarse en un gestor de proyectos. [S06, S07] |
| one sec | Pausas antes de apps, reintervención y bloqueo, incluida conexión con Structured. | Una app gratis; Pro $2.99/mes, $19.99/año o $99.99 vitalicio. | La respiración aislada no es una diferencia suficiente. [S08, S09] |
| Opal | Reglas por horario, tiempo y aperturas; bloqueo y métricas de foco. | Una regla gratis; Pro $19.99/mes, $99.99/año o $399 vitalicio. | La protección debe ser operativa y su estado comprensible. [S10, S11] |
| ScreenZen | Apps seleccionadas, límites, horarios, pausas y seguimiento. | Gratis, financiado con donaciones. | El bloqueo básico por sí solo no demuestra disposición a pagar por Chain. [S12] |

Hay un hallazgo que evita construir una diferenciación falsa: **Structured y one sec ya permiten bloquear apps durante una tarea pendiente y mostrar próximas tareas como alternativas.** Por tanto, unir planificación y protección no es una combinación exclusiva de Chain. [S09]

La oportunidad que sí merece validar es ofrecer hábitos, Plan y protección en un recorrido más directo, con menos configuración y sin duplicar registros. Eso es una hipótesis de producto; no una ventaja demostrada hasta observar uso real. Tampoco los precios anteriores justifican automáticamente un precio de Chain. Se incluye la comparación para entender expectativas y alternativas, no para fijar ahora la suscripción.

## Qué apoya la evidencia sobre rachas y planes

Silverman y Barasch estudiaron cómo se representa una racha en siete estudios. Mostrarla intacta favoreció continuar la conducta frente a mostrarla rota, incluso manteniendo igual la conducta previa; conservar la racha podía convertirse en una meta propia. Permitir repararla atenuó el efecto de la ruptura. Esto respalda tratar con cuidado el regreso tras fallar, pero no demuestra que la mecánica específica de Chain aumente la retención ni que cualquier presión sea beneficiosa. **Aplicación propuesta:** conservar los mínimos y el regreso amable que ya existen, distinguir esfuerzo de protección y comprobar si las personas vuelven después de perder una racha. [S20]

Los experimentos de Gollwitzer y Brandstätter sobre intenciones de implementación apoyan concretar cuándo y dónde se actuará para facilitar cumplir una intención. No comparan planificar de noche frente a planificar por la mañana ni prueban que ordenar una lista produzca productividad general. **Aplicación propuesta:** aprovechar las horas, duraciones y vínculos de Plan para pasar de una intención a una acción concreta. El ritual nocturno es una propuesta de uso a validar, no una promesa científica de superioridad. [S21]

## Cinco correcciones que sí están justificadas

### 1. Evitar que siete días de descanso bloqueen el cálculo

**Confirmado · prioridad alta.** El selector permite marcar toda la semana como descanso. El cálculo de racha retrocede sobre esos días sin aumentar el contador, pero el límite del bucle depende precisamente del contador. Tampoco se detiene en la fecha de creación. La función real superó 1,5 segundos en la reproducción y fue necesario detener el proceso hijo. No se afirma que sea matemáticamente infinito; el límite no protege este caso alcanzable desde la interfaz.

Evidencia: `domain/chains.ts:72–80,209–219`; `app/chain/[id].tsx:584–603`; `components/ui/SevenChoiceSelector.tsx:59–65`.

**Cambio mínimo:** mantener al menos un día activo en el editor de descansos y acotar el cálculo por días examinados y fecha de creación. Las dos defensas son necesarias: la segunda también protege datos guardados anteriormente. No limitar globalmente el selector compartido, porque una repetición sí puede ocurrir los siete días.

**Aceptación:** intentar seleccionar siete descansos muestra una explicación breve; una configuración antigua de siete descansos no bloquea la app.

### 2. Hacer que Repeat reaparezca aunque salte días

**Confirmado · prioridad alta.** Las tareas repetidas se crean al abrir Tomorrow a partir de las tareas de hoy. Una repetición lunes/miércoles/viernes no se copia al martes; el martes desaparece la fuente que permitiría crear la del miércoles. Cargar Today u otra fecha tampoco resuelve esas repeticiones por sí mismo. En la reproducción, martes y miércoles quedaron con cero tareas.

Evidencia: `context/PlanContext.tsx:217–249,277–310,327–337`; `domain/plan.ts:91–119`.

**Cambio mínimo sostenible:** conservar la regla repetida independientemente de sus apariciones diarias y resolver las instancias al cargar cada fecha relevante. La regla debe tener un identificador estable para no duplicar tareas al volver a abrir la misma fecha. Esto termina una opción existente; no añade otro módulo de planificación.

**Aceptación:** una tarea de lunes/miércoles/viernes aparece el miércoles aunque no se haya abierto Chain el martes. Abrirla varias veces no crea duplicados. Si se aplaza la corrección, conviene ocultar temporalmente Repeat.

### 3. No consumir Freeze semanal con una promesa que no se cumple

**Confirmado · prioridad alta.** Freeze puede usarse en Chains semanales, consume un crédito y anuncia protección. Sin embargo, el cálculo semanal solo cuenta completados y mínimos. En una semana con dos acciones de tres, aplicar Freeze el domingo redujo el crédito, mantuvo el resultado en 2/3 y no evitó perder la racha el lunes.

Evidencia: `domain/chains.ts:95–103,186–198,270–275`; `app/chain/[id].tsx:713–742`.

**Cambio mínimo:** reservar Freeze para Chains diarias, también en la corrección de días, y explicar su alcance. La flexibilidad semanal ya procede de cumplir el objetivo en los días elegidos. Diseñar una congelación de semanas sería una mecánica nueva y no la añadiría por defecto.

**Aceptación:** no se ofrecen ni consumen créditos de Freeze en una Chain semanal. En las diarias se conserva la protección y la devolución de crédito cuando corresponda.

### 4. Dar una sola respuesta cuando el objetivo semanal ya está cumplido

**Confirmado · prioridad alta.** Gate considera cumplido un objetivo semanal alcanzado aunque hoy no haya registro. Home de Chains mira únicamente el estado de hoy. Con un objetivo de tres días y registros lunes, miércoles y viernes, el domingo Gate devuelve cero pendientes mientras la portada todavía considera pendiente esa Chain.

Evidencia: `app/(tabs)/index.tsx:95–106`; `context/ChainsContext.tsx:228–230`; selectores `isChainKeptOnDate` y `getGateTodayProgress` de `domain/gateRules.ts:197–225`.

**Cambio mínimo:** compartir una función que resuelva el estado del compromiso para las superficies que lo necesitan. Debe distinguir hecho hoy, mínimo, descanso, congelado y objetivo semanal cubierto. Registrar un extra puede seguir disponible, pero no debe presentarse como una deuda.

**Aceptación:** Home, Gate y el resumen que lo use coinciden en que 3/3 ya cumple el compromiso semanal, manteniendo visible si hubo o no una acción hoy.

### 5. Completar después de Minimum debe mejorar el registro

**Confirmado · prioridad alta.** Después de registrar un mínimo, el detalle ofrece “Mark done today”. El contexto trata mínimo y completado como estados que el mismo toggle debe borrar. Por eso el toque elimina el mínimo en vez de convertirlo en completado; hace falta otro toque para completar. La tarjeta usa el mismo toggle.

Evidencia: `context/ChainsContext.tsx:217–222`; `app/chain/[id].tsx:312,382–386,689–710`; consumidor en `components/ChainCard.tsx`.

**Cambio mínimo:** hacer explícita la intención de completar. Si existe mínimo y se pulsa completar, pasar a Done. Dejar quitar el registro para una acción de deshacer inequívoca o para el editor de días.

**Aceptación:** Minimum → Mark done produce Done con un solo toque. Deshacer continúa siendo posible. Esta corrección importa más que la forma del icono: el símbolo y el resultado deben decir lo mismo.

## Claridad: mejorar lo que aparece, no añadir más información

### Progreso semanal y racha deben tener jerarquías diferentes

En la captura, “0 weeks” pesa más que “1/3”. Es una decisión visual mejorable: quien acaba de actuar debería leer primero **“1 of 3 days this week”** y después la racha. Hay además errores concretos: la progresión usa “A full week” al llegar a siete sin recibir la cadencia, y el detalle llama “1 year” a 365 aunque sean semanas.

Evidencia: `constants/progression.ts:7,13,16–21`; `components/ChainCard.tsx:41–42,148–161,211–216`; `app/chain/[id].tsx:643–657`. Ajustar etiquetas por unidad y sustituir “A real habit” a los treinta por una frase neutral como “Finding your rhythm”. El contador no demuestra automaticidad ni equivale siempre a tiempo de calendario.

### Acercar la acción de hoy al principio del detalle

Actualmente aparecen configuración, racha, hitos e insights antes de “Today's action”. Es un juicio de jerarquía respaldado por el orden del código, no una tasa de abandono medida.

Evidencia: `app/chain/[id].tsx:503–730`. Propuesta: nombre → estado y acción de hoy → progreso reciente → ajustes plegables. Conservar color, schedule y mínimo dentro de “Chain settings”. Agrupar análisis en “Progress”. La tarjeta de Home mantiene el check rápido que ya ofrece.

### Celebrar con menos interrupciones

Cada extra por encima del objetivo semanal activa un modal con Continue; la última tarea vinculada puede encadenar la confirmación del hábito y otra celebración del plan. Los disparadores están confirmados, pero que molesten debe observarse.

Evidencia: `components/ChainCard.tsx:66–75,239–286`; `app/(tabs)/plan.tsx:477–482,603–622`. Usar feedback breve dentro de la tarjeta para los extras. Mantener la pregunta que distingue completar una tarea de completar un hábito; reunir el reconocimiento final en la misma superficie evita otro paso obligatorio.

### Llamar a los insights por lo que miden

Rhythm toma horas de registro y, para sesiones, días con más minutos. Con tres observaciones puede hablar de cuándo sueles protegerte y de tu mejor ventana. Si registras por la noche lo que hiciste por la mañana, eso describe el check-in nocturno, no la actividad.

Evidencia: `app/chain/[id].tsx:99–111,675`; `domain/chains.ts:227,251–265`. Propuesta: “You tend to check in around…” o “Most recorded focus minutes…”, indicando que es un patrón inicial. Ocultar conclusiones cuando aún hay pocos datos. Se corrige el texto; no hace falta un motor de recomendaciones.

### Completar las etiquetas accesibles

La tarjeta anuncia nombre, racha y estado, pero omite el avance semanal; la tira de días se oculta al árbol accesible. En Plan, algunas etiquetas de edición omiten contexto de hora, prioridad y vínculo; ciertos radios usan una semántica distinta del selector compartido.

Evidencia: `components/ChainCard.tsx:132–134,166–168`; `app/(tabs)/plan.tsx:926,930,1083–1085`; `components/ui/SevenChoiceSelector.tsx:86–88`. Añadir resúmenes breves como “Meditate. 1 of 3 days this week. Completed today”. Verificar con VoiceOver en dispositivo; no multiplicar controles para leer siete círculos.

## Lo necesario antes de ofrecer protección y cobrar

### Gate y Windows tienen reglas, pero falta ejecutarlas en iOS

El bridge declara un módulo futuro. Su contrato consulta disponibilidad, autorización, selección y uso; no aplica ni retira restricciones, y no sincroniza horarios. No se encontró implementación nativa correspondiente. Gate usa ejemplos de apps y abre una demostración; guardar Windows conserva datos locales.

Evidencia: `lib/screenTimeBridge.ts:4–9,46–52`; `app/(tabs)/gate.tsx:51–60,523–575`; `lib/gateWindows.ts:84–101`. Los avisos actuales de preview son correctos y deben mantenerse.

Primero probar un recorrido completo con una app seleccionada: permiso → Window → restricción real → salida prevista → fin → retirada del bloqueo. Después probar reinicio, segundo plano, horario nocturno y revocación. Expo Go no permite añadir código nativo propio: hará falta una development build. Family Controls para distribución requiere el proceso correspondiente de Apple; configurar EAS no sustituye implementar y validar la integración. [S13, S14]

### Disponible no significa autorizado ni protegiendo

Settings y Windows se apoyan en que el módulo exista. Además, un uso no recibido puede mostrarse como cero minutos. Eso sería una lectura falsa de ausencia de datos, aunque todavía no se haya ejecutado con un bridge real.

Evidencia: `lib/nativeReadiness.ts:12–23`; `app/settings.tsx:114`; `app/gate-windows.tsx:180–189,265–271,518–519`. Separar permiso pendiente, autorizado, protección activa y error; en uso, carga, dato válido y error. Mostrar cero solo cuando sea una medición válida. Apple diferencia explícitamente la autorización del acceso a la capacidad. [S15]

El interruptor “Pair an iOS Focus” solo guarda `silenceNotifications`; no realiza conexión. Sustituirlo por ayuda para el paso manual reduce confusión. Evidencia: `app/gate-windows.tsx:163–164`; `domain/gateWindows.ts:22–23,160`.

### Suscripción: completar resultado, catálogo y confianza

StoreKit también está preparado como contrato, no como recorrido operativo. El bridge convierte errores en unknown, pero el paywall puede afirmar “Nothing was charged”. Desconocer el resultado no demuestra ausencia de cargo. La normalización admite un snapshot activo con producto ajeno y fecha inválida; la función de entitlements concede Plus a ese estado. Es un defecto del contrato reproducido, no un cobro fraudulento observado ni una integración actualmente explotable.

Evidencia: `domain/subscriptions.ts:7–28`; `lib/subscriptionBridge.ts:12–18,42–50`; `app/paywall.tsx:25–30,82–89`; `domain/entitlements.ts:10–16`. Separar compra verificada, pendiente, cancelada y fallida; validar el producto y refrescar/restaurar el acceso. Apple distingue esos resultados. [S16, S17]

Antes de cobrar, mostrar precio localizado, periodo y alcance, con condiciones, privacidad y soporte accesibles. El diagnóstico de release falla hoy por Privacy policy URL y Support URL; los borradores siguen pendientes. Evidencia: `docs/privacy-policy-draft.md:24–26`, `docs/support-page-draft.md:23–25`; `scripts/release-doctor.js:8–17`. Ese script comprueba campos; no certifica compras ni bloqueos. No activaría nuevas restricciones gratuitas o tiers sin decidir la oferta. [S18, S19]

## Lo que ya está resuelto y conviene conservar

No recomendaría “añadir” mínimos, descansos, corrección de días, recuperación tras un fallo, sesiones de foco, reflexión semanal, prioridad diaria, mover pendientes o briefing matinal: existen. Repeat necesita arreglo, no otra interfaz. Plan ya agrupa opciones avanzadas en Task details y pregunta antes de convertir una tarea en un hábito completado.

Referencias: `app/(tabs)/index.tsx:108–117,245–269`; `app/(tabs)/plan.tsx:786–790,908–932,1131–1161`; `app/chain/[id].tsx:584–625,678–742`.

También existen repositorios versionados, recuperación de corrupción, protección contra versiones futuras, actualizaciones serializadas y compensación de recordatorios. Las pruebas de esos mecanismos aportan confianza en JavaScript, sin acreditar notificaciones reales. Evidencia: `lib/versionedRepository.ts:61,124–137`; las suites de repositorio, Plan y notificaciones revisadas.

El hueco de datos es la portabilidad: Settings describe almacenamiento local pero no ofrece exportar, importar o borrar todo. Una copia dentro del mismo almacenamiento no sustituye una exportación. Añadir tres acciones discretas en Data, con validación y cancelación de recordatorios/protecciones antes del borrado. No hace falta una cuenta ni sincronización en nube. Evidencia: `app/settings.tsx:128–143`; `docs/support-page-draft.md:19–21`.

La paleta, objetivos táctiles de 44 puntos, etiquetas y Reduce Motion ya tienen base. No justificaría rehacer el tema, sustituir todos los iconos ni crear una segunda opción de movimiento. Referencias: `app/chain/new.tsx:215–249`; `components/AnimatedPressable.tsx:35–60`; `components/MilestoneModal.tsx:45–57`.

## Cuatro tandas de trabajo

| Tanda | Alcance | Condición para darla por buena |
|---|---|---|
| 1. Coherencia visual | Aplicar el parche de seis archivos y comprobar estados a tamaño real. | Check, mínimo, descanso y Freeze se distinguen; una acción conserva su significado entre pantallas. |
| 2. Confianza en las reglas | Resolver los cinco casos reproducidos y corregir unidades de hitos. | Cada caso queda cubierto por una regresión útil; Home y Gate coinciden; Repeat no depende de abrir Tomorrow. |
| 3. Claridad y datos | Reordenar detalle, suavizar celebraciones, ajustar insights, etiquetas accesibles y exportación/importación/borrado. | Las tareas habituales requieren menos interpretación y los datos pueden conservarse fuera de la app. |
| 4. Producto nativo y oferta | Un recorrido Screen Time real; después StoreKit, catálogo y páginas de confianza. | Pruebas en dispositivo y entorno de compra correspondiente antes de anunciar bloqueo operativo o cobrar. |

Las tandas indican orden lógico, no fechas estimadas. Puede avanzarse en la preparación nativa mientras se pulen Chains y Plan, pero no conviene mezclar todos los cambios en un único parche manual.

## Cómo decidir qué merece entrar después

Realizaría sesiones formativas con **5–8 personas** del público inicial. Esa cantidad permite observar dificultades; no sirve para estimar conversión o representatividad estadística. Pediría, sin explicar el camino, crear una Chain tres veces por semana, registrar un mínimo, interpretar cada estado, corregir un toque y preparar una tarea vinculada. Con la integración lista, comprobar también si pueden decir qué está protegido y por qué.

Anotar errores, dudas, pasos innecesarios y diferencias entre intención y resultado. Tras varias noches, preguntar qué dejaron de usar y qué duplicaron en otra herramienta. Una corrección entra cuando resuelve un fallo reproducible o una fricción relevante observada. Una función nueva espera cuando solo resulta atractiva en una comparación competitiva.

Por ahora dejaría fuera un feed social, ligas, monedas, otra pestaña, coach de IA, analítica avanzada y una lista extensa de integraciones. No hay evidencia en esta revisión que justifique su coste y complejidad. El producto tiene suficiente contenido para una primera versión convincente; necesita que cada estado y cada promesa se puedan creer.

## Aplicar y verificar el parche

El ZIP `Chain-icon-patch-v1.zip` contiene seis archivos completos en `reemplazar`, sus originales, un diff y un README con pasos para Replit. Guarda un checkpoint, sustituye las rutas correspondientes y recarga Expo Go. Si has editado esos archivos después de enviar el ZIP, aplica solo el diff para conservar tu trabajo. El paquete incluye también notas técnicas y una reproducción de los cinco casos de dominio.

Se han comprobado la aplicación y reversión del diff contra la base, y 75/75 pruebas existentes con el parche. Quedan pendientes el typecheck en el monorepo completo y las comprobaciones de dispositivo indicadas en el README. El parche visual no incorpora las correcciones funcionales propuestas en este informe.

## Fuentes primarias

Consultadas el 6 de septiembre de 2026. No se extrapolan a Chain resultados publicitarios, reseñas aisladas ni porcentajes de otros productos.

- **[S01] Streaks, App Store US:** https://apps.apple.com/us/app/streaks/id963034692
- **[S02] HabitKit, web oficial:** https://habitkit.app/
- **[S03] HabitKit, App Store US:** https://apps.apple.com/us/app/habit-tracker-habitkit/id6443918070
- **[S04] Habitify, planes y condiciones de periodo:** https://intercom.help/habitify-app/en/articles/6113487-explore-habitify-plans-free-plus-and-pro
- **[S05] Habitify, App Store US:** https://apps.apple.com/us/app/habitify-habit-tracker/id1111447047
- **[S06] Structured Pro, funciones y precios:** https://help.structured.app/en/articles/324674
- **[S07] Structured, guía de inicio:** https://help.structured.app/en/articles/380546
- **[S08] one sec, App Store US:** https://apps.apple.com/us/app/one-sec-screen-time-focus/id1532875441
- **[S09] Integración Structured–one sec:** https://tutorials.one-sec.app/en/articles/3035010
- **[S10] Opal, precios y funciones:** https://opalapp.com/pricing
- **[S11] Opal, periodos de compra:** https://opalapp.com/trial
- **[S12] ScreenZen, web oficial:** https://screenzen.co/
- **[S13] Expo, development builds:** https://docs.expo.dev/develop/development-builds/faq/
- **[S14] Apple, Family Controls para distribución:** https://developer.apple.com/documentation/familycontrols/requesting-the-family-controls-entitlement
- **[S15] Apple, AuthorizationCenter:** https://developer.apple.com/documentation/familycontrols/authorizationcenter
- **[S16] Apple, Product.PurchaseResult:** https://developer.apple.com/documentation/storekit/product/purchaseresult
- **[S17] Apple, cambios en suscripciones:** https://developer.apple.com/documentation/storekit/handling-subscriptions-billing
- **[S18] Apple, diseño de compras:** https://developer.apple.com/design/human-interface-guidelines/in-app-purchase
- **[S19] Apple, suscripciones autorrenovables:** https://developer.apple.com/app-store/subscriptions/

- **[S20] Silverman y Barasch, On or Off Track: How (Broken) Streaks Affect Consumer Decisions, publicación anticipada 2022:** https://www.jackiesilverman.com/_files/ugd/0399b5_58713e2052ca4148891dbb00b30a8597.pdf?index=true
- **[S21] Gollwitzer y Brandstätter, Implementation Intentions and Effective Goal Pursuit (1997):** https://sparq.stanford.edu/sites/g/files/sbiybj19021/files/media/file/gollwitzer_brandstatter_1997_-_implementation_intentions_effective_goal_pursuit.pdf

Se excluyó una página antigua de precios de Habitify que contradice sus planes actuales. La página de Opal contiene un texto de facturación contradictorio junto al mensual; se contrastó con su página de trial. Las notas técnicas completas y las reproducciones acompañan esta revisión para que los siguientes parches puedan comprobarse contra casos concretos.

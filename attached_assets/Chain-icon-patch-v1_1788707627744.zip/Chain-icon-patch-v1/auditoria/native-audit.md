# Chain — auditoría de Gate, Apple, suscripción y operación

Fecha: 6 de septiembre de 2026. Revisión de solo lectura del ZIP entregado. Raíz de las referencias: `artifacts/chain/`. No se instalaron dependencias, no se modificó código y no se ejecutó una compilación iOS. No se encontraron archivos AGENTS.md en el espacio de revisión.

## Conclusión

La base de producto contiene bastante más trabajo que una maqueta: persistencia versionada, recuperación local, ventanas programadas y manuales, reglas de Gate y tratamiento de errores. Sin embargo, **Gate y StoreKit son contratos preparatorios, no integraciones nativas operativas**. Lo prioritario es terminar esos dos recorridos y proteger la confianza en los datos; no añadir más pestañas ni gamificación.

## Hallazgos prioritarios — seis como máximo

### N1 · P0 antes de vender protección: completar un recorrido nativo real de principio a fin

- Evidencia: `lib/screenTimeBridge.ts:4–9` declara explícitamente un módulo futuro; el contrato de `:46–52` solo contempla disponibilidad, autorización, selección y uso semanal. No tiene operaciones para aplicar/eliminar restricciones ni para sincronizar horarios o reglas. No se halló implementación Swift/Objective-C, módulo Expo nativo, entitlements o plugin propio en el ZIP.
- Gate sigue usando ocho ejemplos de apps (`app/(tabs)/gate.tsx:51–60`) y abre una ruta de demostración (`:558–575`). Las reglas se guardan localmente (`:523–545`). Guardar una Window escribe AsyncStorage (`lib/gateWindows.ts:84–101`); no instala protección en iOS.
- La UI actual lo reconoce: `app/(tabs)/gate.tsx:111`, `app/gate-windows.tsx:518`, `docs/phase-2-apple-readiness.md:24–32`. Esto debe mantenerse hasta que la función opere.
- Cambio mínimo recomendado: un único prototipo nativo verificable: autorizar una app elegida → aplicar una Window → intentar abrir la app → respetar la pausa/decisión de salida compatible con iOS → finalizar la Window → retirar el bloqueo. Después extender al resto de reglas. Validar también cierre de Chain, reinicio, horario nocturno y revocación del permiso. No diseñar más modos mientras este recorrido esté pendiente.
- Dependencia externa comprobada: Expo Go no permite incorporar código nativo propio; hace falta una development build. Apple exige solicitar autorización de distribución para Family Controls y los targets de extensión que la utilicen. EAS config por sí sola no implementa los módulos ni garantiza la aprobación de esa capacidad.
- Fuentes oficiales: [Expo development builds FAQ](https://docs.expo.dev/develop/development-builds/faq/), [Apple: solicitar Family Controls](https://developer.apple.com/documentation/familycontrols/requesting-the-family-controls-entitlement), [Apple: configurar Family Controls](https://developer.apple.com/documentation/xcode/configuring-family-controls).
- Impacto en alcance: bloqueo para comercializar Gate como protección real, no bloqueo para seguir afinando Chains/Plan en Expo Go.

### N2 · P1 al conectar Apple: diferenciar «disponible», «autorizado», «activo» y «sin datos»

- Evidencia: `getNativeReadiness` usa únicamente `isNativeScreenTimeAvailable` (`lib/nativeReadiness.ts:12–23`). Settings anuncia controles conectados con ese booleano (`app/settings.tsx:114`). Windows retira el aviso de no protección cuando el módulo dice disponible (`app/gate-windows.tsx:265–271,518–519`). Las funciones `requestScreenTimeAuthorization` y `getScreenTimeAuthorizationStatus` existen pero no se usan en pantallas ni contextos.
- Fallo de datos concreto: `ProtectedUsageSheet` consulta disponibilidad y uso de forma independiente (`app/gate-windows.tsx:180–184`). `usage === undefined` se convierte en total cero (`:187`) y `nativeReady` basta para enseñar «0m used across your selected apps» (`:189`). Ocurriría tanto durante carga como si el bridge devuelve undefined por error. No es un cero medido.
- Cambio mínimo: una sola tarjeta de estado con `notConnected / permissionNeeded / permissionDenied / ready / active / error`, derivada de la autorización y confirmación nativa; refrescar al volver a primer plano. En el informe, `loading / empty / ready / error`; solo mostrar cero tras una respuesta válida. Reintento en el mismo sitio, sin añadir pantalla de estadísticas.
- Fuente oficial que diferencia disponibilidad de autorización: [Apple AuthorizationCenter](https://developer.apple.com/documentation/familycontrols/authorizationcenter) y [requestAuthorization(for:)](https://developer.apple.com/documentation/familycontrols/authorizationcenter/requestauthorization(for:)).
- Límite: es un defecto confirmado en la lógica JS que se hará visible al conectar un bridge; no se ha simulado una respuesta nativa en iPhone.

### N3 · P1 antes de cobrar: hacer explícitos los resultados de compra y el acceso verificado

- Evidencia: `domain/subscriptions.ts:7–13` mezcla estado de suscripción con resultado de compra, sin estados pending/cancelled. `lib/subscriptionBridge.ts:42–50` convierte cualquier error en `unknown`. A continuación, `app/paywall.tsx:82–89` afirma «Nothing was charged» ante estados no confirmados; el estado desconocido no demuestra ausencia de cargo.
- Defecto adicional reproducido: `normalizeSubscriptionSnapshot({status:'active', productId:'foreign.product', expirationDate:'bad'})` devuelve `{status:'active'}` (`domain/subscriptions.ts:18–28`). `entitlementsFor(snapshot.status).plus` da `true` (`domain/entitlements.ts:10–16`). El test actual incluso fija ese comportamiento (`tests/native-contracts.test.mjs:17`). No es una vulnerabilidad de cobros explotable ahora: no existe StoreKit operativo y el enforcement no se consume en la app.
- Cambio mínimo: separar `PurchaseResult` (`verifiedSuccess / pending / cancelled / failed / unavailable`) del snapshot de acceso; verificar transacciones en el módulo StoreKit, exigir un producto Chain reconocido y estado coherente antes de conceder Plus, escuchar actualizaciones y restaurar/refrescar la UI. Un estado desconocido debe decir «We couldn’t confirm the purchase yet», permitiendo reconsulta/restauración, sin prometer que no hubo cargo ni lanzar otra compra automáticamente.
- No activar el límite gratuito a una Chain solo porque ya exista una función de entitlements: hay usuarios de early access y la política final aún no se ha decidido.
- Fuente oficial: [Apple Product.PurchaseResult](https://developer.apple.com/documentation/storekit/product/purchaseresult) distingue success, userCancelled y pending. [Apple Handling Subscriptions Billing](https://developer.apple.com/documentation/storekit/handling-subscriptions-billing) describe cambios de estado durante la vida de la suscripción.

### N4 · P1 antes de publicar: oferta comprensible y enlaces de confianza accesibles

- Evidencia: cuando StoreKit está disponible, el precio mostrado se sustituye por «Shown by Apple» (`app/paywall.tsx:25–30`); el bridge no tiene consulta de catálogo (`lib/subscriptionBridge.ts:12–18`). Un pago real todavía mostraría copy de preview (`app/paywall.tsx:119`). No hay enlaces de privacidad, condiciones o soporte en paywall/settings. Los borradores siguen con identidad/contacto pendientes (`docs/privacy-policy-draft.md:24–26`, `docs/support-page-draft.md:23–25`), y `app.json` no tiene sus URLs.
- Prueba: `node scripts/release-doctor.js --app-store` devuelve código 1 y dos requisitos pendientes: Privacy policy URL y Support URL. El script solo comprueba existencia/truthiness (`scripts/release-doctor.js:8–17`); no acredita módulos, compras, HTTPS real, páginas accesibles ni permisos.
- Cambio mínimo: catálogo localizado de Apple, importe total y periodo claros antes de continuar, alcance concreto de Plus, restauración y enlaces de condiciones/privacidad/soporte; si no llega el catálogo, mantener compra deshabilitada y ofrecer reintento. Mantener un solo mensual y anual; no añadir tiers o descuentos ahora. Completar la checklist de release en lugar de interpretar el doctor como certificado de producto listo.
- Fuentes oficiales: [Apple In-app purchase HIG](https://developer.apple.com/design/human-interface-guidelines/in-app-purchase), [Apple Auto-renewable subscriptions](https://developer.apple.com/app-store/subscriptions/). Apple pide importe localizado visible y acceso a política y términos; la hoja de confirmación no sustituye una oferta clara.

### N5 · P2 antes de uso prolongado: permitir conservar y borrar los datos propios

- Evidencia: Settings explica almacenamiento local y ausencia de cuenta (`app/settings.tsx:128–143`), pero no ofrece exportación, importación ni borrado global. Sí existe una copia de recuperación en el mismo almacenamiento (`lib/versionedRepository.ts:61,124–137`); eso recupera corrupción pero no constituye una copia portable fuera de la app. El propio borrador de soporte deja pendiente borrar datos (`docs/support-page-draft.md:19–21`).
- Cambio mínimo: tres acciones discretas en Settings → Data: exportar archivo versionado, importar con validación/vista previa y borrar con confirmación. Incluir Chains, Plan e historial local, excluyendo tokens nativos y recibos. Al borrar, cancelar recordatorios y liberar protecciones antes de vaciar su estado; no basta AsyncStorage.clear().
- Es una recomendación de fiabilidad y control del usuario, no una afirmación de que debamos exigir cuenta o construir cloud sync. iCloud/multidispositivo puede esperar a que usuarios reales lo demanden.
- Límite: no se probó reinstalación ni restauración del backup del sistema operativo. No se puede afirmar qué recuperaría una copia completa del iPhone; el hallazgo es la ausencia de un flujo de datos propio en Chain.

### N6 · P2 simplificación: retirar o convertir en ayuda el interruptor de iOS Focus que no conecta nada

- Evidencia: `app/gate-windows.tsx:163–164` ofrece «Pair an iOS Focus». El control solo conmuta `silenceNotifications`; búsqueda exhaustiva encuentra ese campo únicamente en el modelo/normalizador y ese editor (`domain/gateWindows.ts:22–23,160`). No hay selector, Shortcut, enlace o invocación a Focus. El texto pequeño aclara que marca una asociación manual, pero el control con check parece confirmar una operación.
- Cambio mínimo recomendado ahora: reemplazar el switch por una fila de ayuda «Use with an iOS Focus» que explique el paso manual, o esconderla hasta que haya un recorrido de configuración útil. Esto reduce una opción que hoy añade trabajo sin cambiar el comportamiento del sistema.
- No se afirma que iOS permita activar Focus libremente desde una app. Una integración posterior necesita validación técnica separada. No añadir un cuarto subsistema para resolver esta mejora.

## Lo que ya existe y no hay que recomendar añadir

- Windows programadas, bajo demanda, duración abierta, saltar una ocurrencia, restaurarla, editar y eliminar (`app/gate-windows.tsx:147–165,507–510`).
- Reglas de Gate al abrir o tras minutos de uso, y relajación al completar el día, ya modeladas; falta ejecución nativa, no más opciones (`domain/gateRules.ts`).
- Backup local, recuperación tras corrupción, migraciones y protección ante versiones futuras (`lib/versionedRepository.ts`). El hueco es la portabilidad, no inventar otra capa de persistencia.
- Restore purchases, estado de disponibilidad y contratos StoreKit ya preparados. Hay que completarlos; no diseñar una segunda pantalla de restore.
- Onboarding de tres pasos, sin exigir cuenta (`app/onboarding.tsx:36–64`). No hay evidencia para añadir cuestionarios o personalización extensa. Probar con usuarios si llegar antes a crear la primera Chain mejora la comprensión sería una hipótesis, no un defecto demostrado.
- Reduced Motion, objetivos táctiles y etiquetas accesibles aparecen en Gate/Windows. La revisión visual/física de accesibilidad puede encontrar detalles, pero «añadir accesibilidad desde cero» sería incorrecto.

## Verificación y límites

- Leídos los scripts antes de ejecutarlos. Solo inspección, búsquedas y diagnósticos; cero mutaciones de producto.
- `node --no-warnings --experimental-strip-types --test tests/native-contracts.test.mjs tests/entitlements.test.mjs tests/production-foundation.test.mjs`: 8/8 pasan. Prueban contratos JS y fundamentos, no StoreKit/Screen Time real.
- `node scripts/release-doctor.js --app-store`: falla como se esperaba, 2 requisitos pendientes.
- Reproducción directa del snapshot de producto ajeno: `{snapshot:{status:'active'},plus:true}`.
- No se probó TestFlight, StoreKit sandbox, instalación propia, autorizaciones, bloqueos reales, notificaciones en dispositivo ni compra. Estas ausencias no se presentan como bugs observados del iPhone.


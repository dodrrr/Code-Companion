# Chain · auditoría de claridad y accesibilidad

Fecha: 6 septiembre 2026. Base: código del ZIP actual en `source/artifacts/chain`, además de la captura adjunta visible en la conversación. Auditoría estática: no es una prueba con usuarios, ni una validación de VoiceOver ejecutada en iPhone. No se modificó el código fuente. Los bloqueos nativos de Gate, pagos y persistencia se documentan en los otros anexos.

## Conclusión

La app ya tiene una base cuidada. La oportunidad está en aclarar unidades, rebajar algunas afirmaciones y reducir interrupciones y jerarquías innecesarias. No hace falta ampliar la navegación ni crear otra capa de funcionalidades. Las cinco recomendaciones siguientes son pequeñas y tienen evidencia específica.

## 1. Separar el progreso de esta semana de la racha y corregir los hitos según cadencia

**Prioridad alta.** Hay un error de rotulación demostrable y un ajuste de jerarquía propuesto.

- `constants/progression.ts:7,13,16–21`: `getProgressionStage(streak)` no recibe la cadencia, pero a 7 devuelve `A full week` y a 365 `Year one`.
- `components/ChainCard.tsx:41–42,148–161`: la misma progresión se usa para rachas diarias y semanales. `0 weeks` domina visualmente mientras `1/3` se muestra más pequeño bajo el check (`211–216,307–320`). La captura permite ver exactamente esa combinación en Meditate.
- `app/chain/[id].tsx:643–657`: el hito 365 se rotula `1 year` / `1y` incluso si la unidad de la racha son semanas. No hay que asumir que 365 semanas equivalen a un año.

**Cambio mínimo:** para Chains semanales, poner `1 of 3 days this week` como progreso principal y `0-week streak` como contexto secundario. Usar hitos explícitos `7 weeks kept`, `30 weeks kept`, etc., o etiquetas neutrales sin equivalencias de calendario. En diarias, si se desea celebrar un aniversario real, calcularlo por fechas; los días de racha protegidos y los días de calendario no tienen por qué equivaler. Sustituir el rótulo determinista `A real habit` a 30 por algo como `Finding your rhythm`: un contador no mide por sí solo la automaticidad de un hábito.

**Comprobación de aceptación:** una Chain semanal en 1/3 comunica avance positivo; una racha de 7 semanas no dice `A full week`; ningún hito de 365 semanas dice `1 year`. No añadir gráficos ni puntuaciones nuevas.

## 2. Poner la acción de hoy antes de la analítica en el detalle

**Prioridad media. Juicio de jerarquía UX respaldado por el orden del código**, no medición de abandono.

- `app/chain/[id].tsx:503–625`: nombre, selector de color, schedule y versión mínima.
- `app/chain/[id].tsx:627–677`: hero de racha, milestones, tres insights, RHYTHM y THIS WEEK.
- Solo después aparece `Today's action`, con `Mark done today` / `Log today` y Freeze (`678–730`).

**Cambio mínimo:** nombre → estado de hoy / acción principal → progreso reciente → resto. Mover colores y schedule a un bloque plegable `Chain settings`; agrupar milestones, rhythm y reflexión en un bloque `Progress`. La tarjeta de Home debe seguir resolviendo el check rápido como ahora. El cambio sirve sobre todo cuando alguien entra al detalle para revisar qué le toca o recuperar una acción.

**Comprobación de aceptación:** al abrir el detalle se ve el estado y la acción diaria antes de las estadísticas; se siguen encontrando color, descanso y mínimo sin cambiar su lógica. No proponer un dashboard nuevo.

## 3. Celebrar sin interrumpir cada acción adicional

**Prioridad media.** El disparo de los modales es demostrable; que resulte molesto es una hipótesis UX a validar.

- `components/ChainCard.tsx:66–75`: cada aumento del progreso semanal por encima del objetivo vuelve a activar `celebratingExtra`.
- `components/ChainCard.tsx:239–286`: cada extra muestra un modal centrado con botón `Continue`.
- `app/(tabs)/plan.tsx:477–482,603–622`: la última tarea vinculada puede provocar la confirmación de completar la Chain y, tras aceptarla, otra celebración del plan.

**Cambio mínimo:** extras semanales como feedback breve dentro de la tarjeta (`+1 extra day this week`) con haptic discreto; reservar un modal para pocos hitos relevantes. Mantener la pregunta que diferencia completar una tarea de completar un hábito: esa distinción es útil. Si coincide con el final del plan, incluir el reconocimiento en la misma superficie o mostrarlo sin otro paso obligatorio.

**Comprobación de aceptación:** cuatro días completados sobre un objetivo semanal de tres no requieren cerrar un modal extra para seguir usando la app. Completar la última tarea vinculada no encadena dos pantallas de celebración. No sumar más gamificación.

## 4. Llamar a los insights por lo que realmente miden

**Prioridad alta para confianza.** Hay una diferencia demostrable entre la medición y el texto; no es un fallo en el registro de datos.

- `app/chain/[id].tsx:99–111`: `rhythmFrom` cuenta las horas y días de `completionTimes`; en caso de sesiones usa el día con más minutos registrados.
- `domain/chains.ts:227,251–265`: la hora guardada es por defecto el momento de registrar el estado, no la hora de empezar la actividad.
- `app/chain/[id].tsx:675`: con solo tres registros se afirma `You usually protect this around...`, se identifica un `strongest day`, y se promete encontrar `your best window`.

Si una persona hace deporte por la mañana y marca la Chain al acostarse, el código describe el check-in nocturno. Tampoco tres observaciones demuestran la mejor hora para rendir.

**Cambio mínimo:** `You tend to check in around 9 PM` y `Most recorded focus minutes: Monday`, según la fuente disponible; mostrar el número de registros o `Early pattern`. Retrasar u ocultar el bloque cuando hay poca información. Para ser útil no necesita presentar una recomendación de productividad automática.

**Comprobación de aceptación:** completar de forma retrospectiva no produce una afirmación falsa sobre cuándo hizo la actividad. Los textos distinguen explícitamente registros, sesiones de foco y consejos. No añadir un motor de IA para corregir este problema de copy.

## 5. Llevar el progreso contextual a las etiquetas accesibles

**Prioridad media. Omisiones concretas de semántica, sin declarar una auditoría completa de accesibilidad superada o fallida.**

- `components/ChainCard.tsx:132–134`: la tarjeta anuncia nombre, racha y estado de hoy, pero no el `1/3` semanal.
- `components/ChainCard.tsx:166–168`: la tira semanal se oculta explícitamente del árbol accesible; el resumen de la tarjeta tampoco contiene los estados de los siete días.
- `app/(tabs)/plan.tsx:1083–1085`: el bloque editable tiene una etiqueta explícita `Edit [task]`; sus datos de hora, prioridad y Chain asociada no se incluyen en esa etiqueta. Es conveniente verificar qué anuncia cada plataforma porque el agrupado de descendientes depende del comportamiento nativo.
- `app/(tabs)/plan.tsx:926,930`: varias opciones con `accessibilityRole="radio"` declaran `selected`, mientras el selector compartido declara `checked` (`components/ui/SevenChoiceSelector.tsx:86–88`). Unificar su semántica.

**Cambio mínimo:** por ejemplo `Meditate. 1 of 3 days this week. 0-week streak. Completed today.` y `Edit Read 10 pages. Tomorrow at 8 PM. One thing. Linked to Read.` Para la tira semanal, mantener una parada breve en vez de forzar siete controles innecesarios: añadir un resumen de días en `accessibilityValue` o un acceso al calendario, que ya anuncia fechas y estados completos (`app/chain/[id].tsx:192–216`).

**Comprobación de aceptación:** recorrer con VoiceOver una Chain diaria y otra semanal, una tarea con hora, una tarea con prioridad y otra vinculada. Se conocen estado, progreso y función antes de actuar; cada radio anuncia su selección. No multiplicar pantallas de configuración.

## Qué ya está bien y no volvería a construir

- **Colores y selección:** existen seis colores iniciales y extras plegados; los selectores usan anillo y check además del color (`app/chain/new.tsx:215–249`). Incluyen nombres accesibles. `readableTextColor` y `readableAccentColor` están centralizados en `constants/sectionTheme.ts` y ya se usan en controles y tarjetas. No hay fundamento para reemplazar toda la paleta.
- **Objetivos táctiles:** el sistema define 44 puntos; `IconButton`, checks de Chains, checks de Plan y `SevenChoiceSelector` lo aplican. El círculo visual de 36 del selector está dentro de un target de 44, así que no debe confundirse el diámetro decorativo con el área pulsable. Queda probar el calendario a tamaños estrechos, no declarar que todo está roto.
- **Movimiento:** `AnimatedPressable.tsx:35–60`, `ChainCard.tsx:77–95` y `MilestoneModal.tsx:45–57` ya respetan Reduce Motion. No proponer una opción duplicada dentro de Settings.
- **Modo oscuro / materiales:** `app.json:9` declara tema oscuro; `constants/colors.ts` comparte esa paleta entre light y dark de forma coherente con la intención actual. `AmbientSurface.tsx:88–108` limita glass nativo a superficies elevadas y usa una superficie casi opaca de fallback. No hay evidencia que justifique rehacer la app en modo claro. Reduce Transparency y contraste con glass nativo son verificaciones pendientes en dispositivo; no se ha demostrado un fallo de render aquí.
- **Regreso tras un fallo:** Home ya ofrece `RETURN TODAY`, `One miss does not end...` y `Log minimum` (`app/(tabs)/index.tsx:108–117,245–269`). No añadir un recovery flow nuevo.
- **Cierre y pendientes:** ya hay `Nightly reset`, `Move` y `Let go` (`app/(tabs)/plan.tsx:786–790,1139–1161`). No proponer por error una función que ya existe.
- **Complejidad del Plan:** repetición, color, foco y recordatorios ya se agrupan en `Task details` (`app/(tabs)/plan.tsx:908–932`); conservar esta revelación progresiva.
- **Tarea frente a hábito:** la confirmación `Does that complete [Chain] for today?` es una buena salvaguarda semántica (`app/(tabs)/plan.tsx:1131–1136`). Mejor hacerla fluida que eliminarla mediante autocompletado implícito.

## Alcance visual del parche de iconos

El problema del check admite una solución de familia, sin rediseño de todas las pantallas: peso óptico coherente en check, mínimo, descanso y freeze; checks de Chain y Plan con la misma geometría; conservar estados distinguibles. El código actual ya centraliza add/check/minimum en `components/ui/ChainSymbol.tsx`, así que esa es una base pequeña y adecuada. El icono no debe sustituirse por un eslabón ambiguo que haga perder el significado de completado.

# Notas técnicas y diagnóstico

Estos anexos describen el código original. No son archivos para sustituir dentro de la app. Los fallos siguen pendientes tras el parche visual.

Para reproducir los cinco casos, copia solo `repro-dominio.mjs` a la raíz de tu monorepo Replit (la que contiene `artifacts/chain`). Con una versión de Node que soporte TypeScript strip-types, ejecuta:

```bash
node --no-warnings --experimental-strip-types repro-dominio.mjs
```

El diagnóstico no escribe datos de tu app. Usa objetos de ejemplo y ejecuta el caso de siete descansos en un proceso hijo con un límite de 1,5 segundos. Reproduce funciones de dominio y los predicados documentados de la interfaz; no automatiza un iPhone. Los asserts comprueban la presencia de los defectos en esta versión: tras corregirlos habrá que sustituirlos por pruebas que exijan el comportamiento correcto.

Las líneas de los anexos corresponden a la copia original del ZIP recibido. Los cambios de iconos pueden desplazarlas. El informe principal contiene las recomendaciones priorizadas; estos anexos aportan detalle para implementar cada arreglo posterior.

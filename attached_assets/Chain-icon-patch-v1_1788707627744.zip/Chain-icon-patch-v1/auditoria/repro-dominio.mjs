import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { applyDayStatus, getStreak, getWeeklyProgress, isRestDay, normalizeChain } from './artifacts/chain/domain/chains.ts';
import { resolvePlanForDate } from './artifacts/chain/domain/plan.ts';
import { getGateTodayProgress } from './artifacts/chain/domain/gateRules.ts';

const base = {
  id: 'audit', name: 'Read', color: '#ff6b3d', createdAt: '2026-08-24',
  completedDates: [], minimumDates: [], minimumLabel: 'One page', frozenDates: [],
  freezeCredits: 2, freezeRecoveryProgress: 0, freezeRecoveryCountedDates: [],
  freezeSystemVersion: 2, restDays: [], cadence: 'daily', weeklyTarget: 3, completionTimes: {},
};

if (process.argv.includes('--all-rest-worker')) {
  const chain = normalizeChain({ ...base, restDays: [0, 1, 2, 3, 4, 5, 6] });
  console.log('All seven rest days accepted:', chain.restDays.length);
  console.log('Streak:', getStreak(chain, '2026-09-06'));
  process.exit(0);
}

// Execute the actual implementation in a killable child; never freeze the audit process.
let allRestBlocked = false;
try {
  execFileSync(process.execPath, ['--no-warnings', '--experimental-strip-types', fileURLToPath(import.meta.url), '--all-rest-worker'], { timeout: 1500 });
} catch (error) {
  allRestBlocked = error.code === 'ETIMEDOUT';
  console.log('1. Seven rest days:', allRestBlocked ? 'actual getStreak exceeded 1.5 seconds and required termination' : String(error));
}
assert.equal(allRestBlocked, true);

// Mirror only the two documented successive showTomorrow calls using the actual domain function.
const monday = [{ id: 'repeat', text: 'Study', timeSlot: '8 AM', completed: false, planDate: '2026-08-31', repeatDays: [1, 3, 5] }];
const tuesday = resolvePlanForDate([], monday, '2026-09-01', () => 'tuesday');
const wednesday = resolvePlanForDate([], tuesday, '2026-09-02', () => 'wednesday');
assert.equal(tuesday.length, 0);
assert.equal(wednesday.length, 0);
console.log('2. Repeat Monday/Wednesday/Friday: Wednesday has', wednesday.length, 'items when each Tomorrow is resolved from Today.');

let weekly = { ...base, cadence: 'weekly', weeklyTarget: 3, completedDates: ['2026-08-24', '2026-08-26', '2026-08-28', '2026-08-31', '2026-09-02'] };
assert.equal(getStreak(weekly, '2026-09-06'), 1);
weekly = applyDayStatus(weekly, '2026-09-06', 'frozen').chain;
assert.equal(weekly.freezeCredits, 1);
assert.equal(getWeeklyProgress(weekly, '2026-09-06'), 2);
assert.equal(getStreak(weekly, '2026-09-07'), 0);
console.log('3. Weekly Freeze: spends a token on Sunday, current week stays 2/3, Monday streak becomes 0 despite UI claim of protection.');

const weeklyMet = { ...base, cadence: 'weekly', completedDates: ['2026-08-31', '2026-09-02', '2026-09-04'] };
const today = '2026-09-06';
const protectedToday = chain => chain.completedDates.includes(today) || chain.minimumDates.includes(today) || chain.frozenDates.includes(today);
const homePending = [weeklyMet].filter(chain => !isRestDay(chain, today)).filter(chain => !protectedToday(chain) && !chain.frozenDates.includes(today)).length;
const gate = getGateTodayProgress([weeklyMet], today);
assert.equal(homePending, 1);
assert.equal(gate.pending, 0);
console.log('4. Weekly target reached Friday: Sunday Home pending =', homePending, ', Gate pending =', gate.pending);

const minimum = applyDayStatus(base, today, 'minimum').chain;
// Exact status predicate used by ChainsContext.toggleToday, followed by actual domain mutation.
const nextStatus = minimum.completedDates.includes(today) || minimum.minimumDates.includes(today) ? 'missed' : 'done';
const afterPrimaryAction = applyDayStatus(minimum, today, nextStatus).chain;
assert.equal(afterPrimaryAction.completedDates.includes(today), false);
assert.equal(afterPrimaryAction.minimumDates.includes(today), false);
console.log('5. Minimum -> primary Mark done action: next status =', nextStatus, '; minimum and completion both absent.');

console.log('Five audit cases reproduced. Pure domain/code-path reproduction; no native device execution.');

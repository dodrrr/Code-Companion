# Chain — auditoría de dominio y persistencia

Fecha: 6 de septiembre de 2026. Alcance: `domain/chains.ts`, `domain/plan.ts`, `context/ChainsContext.tsx`, `context/PlanContext.tsx`, `lib/versionedRepository.ts`, notificaciones de Plan y sus consumidores directos. Lectura y ejecución de pruebas; **sin modificar fuente**. No se encontró `AGENTS.md` dentro del árbol revisado. Las líneas corresponden a la copia examinada y pueden desplazarse con el parche visual paralelo.

## Resultado

La base ya incorpora bastante funcionalidad y defensas de persistencia. **No recomiendo añadir más módulos.** Hay cinco problemas concretos que conviene resolver para que las promesas actuales sean coherentes. Los cinco tienen reproducción de dominio o de la combinación exacta de funciones y predicados usados por los consumidores. No son una validación de ejecución en iPhone.

- Suite existente: `node --no-warnings --experimental-strip-types --test tests/*.test.mjs` → **75 aprobados, 0 fallos**.
- Reproducción adicional: ver instrucciones de `auditoria/README.md` en el paquete.
- No se instalaron dependencias ni se modificaron pruebas o código del producto.

## 1. Seleccionar los siete días de descanso puede bloquear el cálculo de la racha

**Clasificación:** Confirmado, código + reproducción. **Prioridad:** P1, antes de una beta amplia.

**Dónde:** `domain/chains.ts:209–219`; validación en `domain/chains.ts:72–80`; selector de descansos en `app/chain/[id].tsx:584–603`; selección múltiple sin límite en `components/ui/SevenChoiceSelector.tsx:59–65`.

El selector permite marcar los siete días como descanso. La normalización conserva esa configuración. `getStreak` retrocede por los días de descanso sin incrementar `streak`, pero su única condición de límite es `streak < 3650`; tampoco se detiene en `createdAt`. Un Chain válido con siete descansos excedió **1,5 segundos** en la función real y hubo que terminar el proceso hijo. No afirmo que sea un bucle matemáticamente infinito; sí que el límite no limita las iteraciones del caso alcanzable desde la UI y puede bloquear el hilo de JavaScript.

**Repro de usuario:** detalle de una Chain diaria → Weekly schedule → seleccionar los siete días.

**Cambio mínimo:** impedir los siete descansos en ese selector específico, con un mensaje breve que mantenga al menos un día activo. Además, acotar el recorrido de `getStreak` por fecha de creación y número de días examinados para proteger datos ya guardados. No limitar globalmente `SevenChoiceSelector`, porque Repeat sí debe poder seleccionar siete días.

## 2. Repeat pierde tareas cuando la recurrencia salta días o no se prepara Tomorrow

**Clasificación:** Confirmado, código + reproducción. **Prioridad:** P1.

**Dónde:** `context/PlanContext.tsx:299–310` frente a `217–249`, `277–295` y `327–337`; `domain/plan.ts:91–119` (`resolvePlanForDate`).

Las recurrencias solo se materializan al abrir Tomorrow, leyendo como fuente las tareas de hoy. Si una tarea es lunes/miércoles/viernes, el lunes no se copia al martes. El martes ya no hay una tarea fuente de la que crear la del miércoles. Tampoco la hidratación, Show Today o Show Date generan las recurrencias por sí mismos.

**Repro:** tarea el lunes 31/08/2026 con `repeatDays: [1,3,5]`; abrir Tomorrow ese lunes crea cero tareas para el martes. Al resolver Tomorrow desde ese martes, el miércoles sigue vacío. Reproducción con la función real: `Tuesday=0`, `Wednesday=0`, cuando debería haber una tarea el miércoles.

**Impacto:** la función existente no cumple “Choose the days this task returns”. El usuario puede interpretar la ausencia como pérdida de su planificación.

**Cambio mínimo sostenible:** guardar la regla recurrente independientemente de sus instancias diarias; resolverla de forma idempotente cuando se carga cualquier fecha relevante, sin exigir abrir la app la noche anterior. Mantener una clave de origen estable para evitar duplicados. Esto corrige Repeat, no añade una nueva función. Si se decide aplazar ese arreglo, ocultar temporalmente Repeat es más honesto que presentar la opción como terminada.

## 3. Freeze semanal consume un crédito pero no protege la racha semanal

**Clasificación:** Confirmado, código + reproducción. **Prioridad:** P1.

**Dónde:** `domain/chains.ts:95–103`, `186–198`, `270–275`; botón y promesa en `app/chain/[id].tsx:713–742`.

El botón Freeze está disponible también para Chains semanales. Consume un crédito y muestra “Today is frozen — your streak is protected”. Sin embargo, el progreso y la racha semanal cuentan únicamente `completedDates + minimumDates`, nunca `frozenDates`.

**Repro:** una semana anterior cumplida; semana actual con dos de tres acciones; aplicar Freeze el domingo. Los créditos bajan de dos a uno y la semana se mantiene en 2/3. El lunes la racha pasa de una semana a cero.

**Cambio mínimo:** definir el alcance de Freeze explícitamente. La solución de menor complejidad es ofrecerlo solo para Chains diarias, incluido el editor de días, y mantener la flexibilidad semanal en el objetivo de días. Crear “Freeze de semana” sería una función nueva y necesita una decisión de producto; no la recomiendo por defecto.

## 4. Chains y Gate discrepan sobre un objetivo semanal ya cumplido

**Clasificación:** Confirmado, código + reproducción de los selectores. **Prioridad:** P1/P2.

**Dónde:** `app/(tabs)/index.tsx:95–106`; `context/ChainsContext.tsx:228–230` (`isProtectedToday`); `domain/gateRules.ts` (`isChainKeptOnDate`, `getGateTodayProgress`).

Gate reconoce como cumplida una Chain semanal que ya alcanzó su objetivo aunque hoy no se haya registrado nada. La portada de Chains únicamente comprueba si existe un registro de hoy. Por tanto, el mismo compromiso puede estar pendiente en Chains y liberado en Gate.

**Repro:** objetivo 3/semana, registros lunes/miércoles/viernes, abrir el domingo. Predicado de portada: una Chain pendiente. Selector real de Gate: cero pendientes y `isKept=true`.

**Impacto:** la app puede volver a pedir un mínimo o mostrar una intervención cuando la persona ya hizo lo que acordó para esa semana. Esa presión extra contradice el ritmo semanal.

**Cambio mínimo:** compartir una única función de estado del compromiso entre portada, Plan y Gate, que distinga `done today`, `minimum today`, `frozen today`, `rest day` y `weekly target met`. Mantener la posibilidad de registrar un extra sin presentarlo como deuda. No hace falta una nueva pantalla.

## 5. Después de Minimum, “Mark done today” borra el mínimo en lugar de completar

**Clasificación:** Confirmado, código + reproducción. **Prioridad:** P1/P2, especialmente relevante para el check solicitado.

**Dónde:** `context/ChainsContext.tsx:217–222` (`toggleToday`); `app/chain/[id].tsx:312`, `382–386`, `689–710`. El check de `components/ChainCard.tsx` utiliza el mismo `toggleToday`.

El detalle define `done` solo con una entrada en `completedDates`; por tanto, después de un mínimo, presenta “Mark done today”. Pero `toggleToday` trata tanto `completedDates` como `minimumDates` como estados que deben convertirse en `missed`. Al pulsar el botón no eleva Minimum a Done: elimina el mínimo. Hace falta un segundo toque para completar.

**Repro:** registrar mínimo → abrir detalle → pulsar “Mark done today”. Resultado real del predicado de contexto + mutación de dominio: ni `minimumDates` ni `completedDates` contienen hoy.

**Cambio mínimo:** al convertir la intención primaria de “completar” en estado, pasar explícitamente a `done` si hoy no está plenamente completado. Reservar `missed` para deshacer una finalización o una acción explícita de quitar registro. Mantener el editor de días para correcciones. Acompañar el nuevo icono con estados inequívocos, no solo con un cambio decorativo.

## Funciones existentes: no proponerlas otra vez como nuevas

- Hábitos diarios y objetivos semanales de 1 a 7 días.
- Descansos configurables por día.
- Mínimo personalizable, contado como progreso y representado por separado.
- Dos créditos de Freeze y recuperación tras catorce completados reales; protección contra obtener créditos alternando la misma fecha.
- Corrección de hoy y los tres días anteriores en el calendario, limitada por la fecha de creación.
- Deshacer una finalización, cambiar estado y recuperar un crédito al quitar un Freeze.
- Tareas de Plan vinculadas a Chains, con confirmación antes de completar la Chain.
- Una prioridad diaria, duración de tareas, mover o copiar a mañana, cerrar y reabrir el día.
- Repeat existe, aunque necesita la corrección del punto 2.
- Recordatorios, aplazamiento de quince minutos y notificación matinal configurable.
- Sesión de foco, registro de minutos y relación con el compromiso.
- Rachas, progreso semanal, hitos, consistencia, ritmo y reflexión semanal ya están presentes.

## Aspectos de persistencia y fechas que ya están razonablemente defendidos

- Repositorios con versión y copia de respaldo; reparan el primario corrupto desde una copia válida y no sobrescriben datos de versiones futuras.
- Las actualizaciones semánticas de Plan están serializadas por fecha; las pruebas cubren cambios concurrentes de completado y recordatorios.
- La migración de Chains respeta un repositorio vacío válido y no reintroduce hábitos borrados desde la versión antigua.
- Los fallos de escritura se reportan y existen mecanismos de reconciliación de la UI optimista.
- Mover una tarea escribe primero el destino: un fallo entre ambas operaciones puede dejar un duplicado recuperable, pero evita perderla de ambos días. El comentario del código documenta esta decisión.
- Fechas de Plan y Chains usan calendario local; Plan dispone de actualización a medianoche y al volver al primer plano.
- La edición histórica de Chains evita fechas futuras desde la UI; las pruebas validan fechas reales y años bisiestos.
- Cancelación de recordatorios antes de acciones dependientes, compensación de notificaciones huérfanas y cola de reemplazo del briefing matinal están implementadas. Falta la prueba en dispositivo para acreditar comportamiento real de iOS; no presentarlo como verificado en esta auditoría.

No identifico evidencia suficiente para recomendar añadir IA, métricas adicionales, otra pestaña o nuevas mecánicas de gamificación. La mejora con más valor es que estas funciones actuales compartan las mismas reglas y no contradigan la intención del usuario.

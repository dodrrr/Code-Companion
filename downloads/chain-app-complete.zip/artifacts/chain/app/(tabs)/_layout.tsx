import React from 'react';
import { Platform, StyleSheet, useColorScheme, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { SECTION_ACCENTS } from '@/constants/sectionTheme';
import { Feather } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { isLiquidGlassAvailable } from 'expo-glass-effect';
import { Tabs } from 'expo-router';
import { NativeTabs } from 'expo-router/unstable-native-tabs';
import { SymbolView } from 'expo-symbols';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

function NativeTabLayout() {
  return (
    <NativeTabs
      backgroundColor="rgba(12,12,14,0.76)"
      blurEffect="systemUltraThinMaterialDark"
      shadowColor="rgba(255,255,255,0.10)"
      disableTransparentOnScrollEdge
    >
      <NativeTabs.Trigger name="index">
        <NativeTabs.Trigger.Icon sf={{ default: 'link', selected: 'link' }} selectedColor={SECTION_ACCENTS.today} />
        <NativeTabs.Trigger.Label selectedStyle={{ color: SECTION_ACCENTS.today, fontWeight: '600' }}>Chains</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="gate">
        <NativeTabs.Trigger.Icon sf={{ default: 'shield', selected: 'shield.fill' }} selectedColor={SECTION_ACCENTS.gate} />
        <NativeTabs.Trigger.Label selectedStyle={{ color: SECTION_ACCENTS.gate, fontWeight: '600' }}>Gate</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="plan">
        <NativeTabs.Trigger.Icon sf={{ default: 'moon', selected: 'moon.fill' }} selectedColor={SECTION_ACCENTS.plan} />
        <NativeTabs.Trigger.Label selectedStyle={{ color: SECTION_ACCENTS.plan, fontWeight: '600' }}>Plan</NativeTabs.Trigger.Label>
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}

function ClassicTabLayout() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const isIOS = Platform.OS === 'ios';
  const isWeb = Platform.OS === 'web';
  const safeAreaInsets = useSafeAreaInsets();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarInactiveTintColor: colors.mutedForeground,
        tabBarStyle: {
          position: 'absolute',
          backgroundColor: isIOS ? 'transparent' : colors.background,
          borderTopWidth: isWeb ? 1 : 0,
          borderTopColor: colors.border,
          elevation: 0,
          paddingBottom: safeAreaInsets.bottom,
          ...(isWeb ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <View style={[StyleSheet.absoluteFill, styles.tabGlass]}>
              <BlurView intensity={48} tint={isDark ? 'dark' : 'dark'} style={StyleSheet.absoluteFill} />
              <LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.075)', 'rgba(255,255,255,0.018)', 'rgba(0,0,0,0.08)']} style={StyleSheet.absoluteFill} />
            </View>
          ) : isWeb ? (
            <View
              style={[
                StyleSheet.absoluteFill,
                { backgroundColor: colors.background },
              ]}
            />
          ) : null,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Chains',
          tabBarActiveTintColor: SECTION_ACCENTS.today,
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="link" tintColor={color} size={22} />
            ) : (
              <Feather name="link" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen
        name="gate"
        options={{
          title: 'Gate',
          tabBarActiveTintColor: SECTION_ACCENTS.gate,
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="shield.fill" tintColor={color} size={22} />
            ) : (
              <Feather name="shield" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen
        name="plan"
        options={{
          title: 'Plan',
          tabBarActiveTintColor: SECTION_ACCENTS.plan,
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="moon.fill" tintColor={color} size={22} />
            ) : (
              <Feather name="moon" size={22} color={color} />
            ),
        }}
      />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabGlass: { borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: 'rgba(255,255,255,0.14)' },
});

export default function TabLayout() {
  // NativeTabs is iOS-only; always fall back to ClassicTabLayout on web/Android
  if (Platform.OS === 'ios' && isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}
